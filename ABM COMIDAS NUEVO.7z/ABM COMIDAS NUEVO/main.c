#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

#define TAM 3
#define TAMMENU 5
typedef struct
{
    int idMenu;
    char descripcionMenu[20];
    float precio;
} eMenu;

typedef struct
{
    int dia;
    int mes;
    int anio;
} eFecha;

typedef struct{
    int id;
    char descripcion[20];
}eSector;

typedef struct
{
    int empleadoLegajo;
    int menuCodigo;
    int fecha;
} eAlmuerzo;

typedef struct
{
    int legajo;
    char nombre[20];
    char apellido[20];
    char sexo;
    float sueldo;
    int estado;
    eFecha fecha;
    int idSector;
} eEmpleado;

void inicializarEmpleado(eEmpleado vec[],int );
void mostrarEmpleado(eSector sectores[], int tam, eEmpleado empleado,eMenu menu);

int main()
{

    char seguir='s';
    int opcion=0;

    eSector sectores[TAMMENU]=
    {
        {1, "RECURSOS HUMANOS"},
        {2, "COMPRAS"},
        {3, "VENTAS"},
        {4, "LOGISTICA"},
        {5, "MARKETING"}
    };

    eEmpleado empleado[TAM]= {
        {123,"Juan","Perez",'m',2344,1,{29 / 10 / 5 }, 1},
        {1234,"Maria","Garcia",'f',223344,1,{29 / 10 / 5 }, 1},
        {321,"Jorge","Diaz",'m',232344,0,{29 / 10 / 5 }, 3}
        };

    eMenu menues[]= {
    {1,"MILANESAS", 23.4},
    {2,"ENSALADA", 13.4},
    {3,"PURE", 20.4},
    {4,"PANCHOS", 21},
    {5,"ASADO", 50}};

    while(seguir=='s')
    {
        printf(" ***************  ABM ALMUERZOS ***************  \n");

        printf("1- Menues\n");
        printf("2- Empleados\n");
        printf("3- Almuerzos\n");
        printf("4- Salir\n\n");

        printf("Ingrese opcion :");
        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            system("cls");
            printf("1 -ALTA MENU\n");
            printf("2 -MODIFICAR MENU\n");
            printf("3 -BAJA MENU\n");
            printf("4 -LISTAR MENU\n");
            printf("5 -Salir\n");
            printf("Ingrese una opcion :");
            scanf("%d", &opcion);
            switch(opcion)
            {
            case 1:
                printf("Alta MENU");
                break;
            case 2:
                printf("Modificar MENU");
                break;
            case 3:
                printf("Bbaja MENU");
                break;
            case 4:
                printf("Listar MENU");
                break;
            case 5:

                break;
            default:
                printf("Error, reingrese una opcion correcta (1-5)");
            break;
            }

            break;
        case 2:

            system("cls");
            printf("1 -Alta empleado\n");
            printf("2 -Modificar empleado\n");
            printf("3 -Baja empleado\n");
            printf("4 -Listar empleado\n");
            printf("5 -Salir\n");
            printf("Ingrese una opcion :");

            scanf("%d", &opcion);
            switch(opcion)
            {
            case 1:
                printf("Alta empleado");
                break;
            case 2:
                printf("Modificar empleado");
                break;
            case 3:
                printf("Baja empleado");
                break;
            case 4:
                mostrarEmpleados(empleado, TAM, sectores, TAMMENU, menues);
                break;
            case 5:

                break;
            default:
                printf("Error, reingrese una opcion correcta (1-5)");
            break;
            }

        case 3:
            printf(" ALMUERZOS");

            break;

        default:
            printf("Error, reingrese una opcion correcta (1-3)");
            break;
        }
        getch();
        system("cls");
    }
    return 0;
}

void inicializarEmpleado(eEmpleado empleado[], int tam)
{
    for(int i=0; i<tam; i++)
    {
        empleado[i].estado=0;
    }
}

int obtenerSector(eSector sectores[], int tam, int idSector, char desc[])
{
    int todoOk = 0;

    for(int i=0; i < tam; i++)
    {

        if(idSector == sectores[i].id)
        {

            strcpy(desc, sectores[i].descripcion);
            todoOk = 1;
            break;
        }
    }

    return todoOk;
}

void mostrarEmpleado(eSector sectores[], int tam, eEmpleado empleado, eMenu menu)
{
    char desc[20];
    int consiguioNombre;

    consiguioNombre =  obtenerSector(sectores, tam, empleado.idSector, desc);

    if( !consiguioNombre )
    {
        strcpy(desc, "Sin definir");
    }
    printf("%10d %12s %4c   %10.2f %4d/ %3d/ %3d %12s - %d %d %s %f\n",empleado.legajo, empleado.nombre, empleado.sexo, empleado.sueldo, empleado.fecha.dia, empleado.fecha.mes, empleado.fecha.anio, desc,empleado.idSector, menu.idMenu, menu.descripcionMenu, menu.precio);
}

void mostrarEmpleados(eEmpleado empleado[], int tam, eSector sectores[], int tamSector, eMenu menu[])
{
    int    contador =1;


    for(int i=0; i<tam; i++)
    {
        if(empleado[i].estado ==1)
        {
            mostrarEmpleado(sectores, tamSector, empleado[i], menu[i]);
            contador++;
        }
        if(contador== 0)
        {
            printf("\nNo existe ningun empleado registrado");
        }
    }

}



