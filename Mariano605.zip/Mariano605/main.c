#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
typedef struct
{
    int codAutor;
    char apellido[31];
    char nombre[31];

} eAutores;

typedef struct
{
    int codLibro;
    char titulo[20];
    int codAutor;
} eLibros;

typedef struct
{
    int dia;
    int mes;
    int anio;
} eFecha;

typedef struct
{
    int codSocio;
    char apellido[31];
    char nombre[31];
    char sexo;
    int telefono; // MAX 16 Caracteres
    char email[31];
    eFecha fechaAsociado;
    int estado;
} eSocios;

typedef struct
{
    int codigoPrestamo;
    int codigoLibro;
    int codigoSocio;
    eFecha fechaPrestamo;
} ePrestamos;


void mostrarLibros (eLibros libro[], int tam);
void bajaSocio(eSocios socio[],int tamSocio);
void altaSocio (eSocios socio[], int tam);
void mostrarSocios(eSocios socio[], int tam);
void mostrarAutores(eAutores autores[],int tam);
int buscarLibreSocio( eSocios socio[], int tam);
void getValidStringRango(char requestMessage[],char errorMessage[], char input[], int tamanio);
int getStringLetrasRango(char mensaje[],char input[], int tamanio);
void getString(char mensaje[],char input[]);
int esSoloLetras(char str[]);
void corregirMayusculas(char input[]);
char getValidChar(char requestMessage[], char errorMessage[], char comparacionA, char comparacionB);
int getValidInt(char requestMessage[],char errorMessage[]);
int getStringNumeros(char mensaje[],char input[], int tam);
int getValidIntRango(char requestMessage[],char errorMessage[], int lowLimit, int hiLimit);
int esNumerico(char str[]);
int getStringNumerosRango(char mensaje[],char input[], int tamanio);
int getStringNumeros(char mensaje[],char input[], int tam);
int getValidIntTope(char requestMessage[],char errorMessage[], int tam);


int main()
{
    int opcion;
    char seguir = 's';

    eAutores autores [] = {{1, "Jose","Perez"}
        ,{2, "Francisco","Diaz"}
        ,{3, "Roberto","Rodriguez"}
        ,{4, "Maria","Iturbe"}
        ,{5, "Juan","Loi"}
        ,{6, "Marcos","Vazquez"}
        ,{7, "Enrique","Solis"}
        ,{8, "Mariano","Parra"}
        ,{9, "Pepe","Juanae"}
        ,{10, "Santiago","Peaser"}
    };

    eLibros libros [] = {{100,"La casa", 1}
        ,{101,"La nueva era", 2}
        ,{102,"El chavo", 3}
        ,{103,"Juanito", 4}
        ,{104,"Oliver", 5}
        ,{105,"Juana de arco", 6}
        ,{106,"Caperucita", 7}
        ,{107,"Programacion", 8}
        ,{108,"Messi", 9}
        ,{109,"Maradona", 10}
    };

    eSocios socios [10] =
    {
        {1000,"Juan","Perez",'m', 155150201, "juana@hotmail.com",{29,04,94},1},
        {1001,"Santiago","Diaz",'m', 155150201, "santiago123@hotmail.com",{29,04,94},1},
        {1002,"Mariano","Scardamaglia",'m', 155150201, "mariano123@hotmail.com",{29,04,94},1},
        {1003,"Eduardo","Acevecdo",'m', 155150201, "jedu230@hotmail.com",{29,04,94},1},
        {1004,"Julian","Paul",'m', 155150201, "juli23034@hotmail.com",{29,04,94},1}
    };

    while(seguir=='s')
    {
        printf(" ***************  ABM SOCIOS ***************  \n");

        printf("1- Alta\n");
        printf("2- Modificar \n");
        printf("3- Baja\n");
        printf("4- Listar socios\n");
        printf("5- Listar libros\n");
        printf("6- Listar autores\n");
        printf("7- Prestamos\n");
        printf("8- Salir\n\n");

        printf("Ingrese opcion :");
        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            altaSocio(socios, 10);

            break;
        case 2:

            scanf("%d", &opcion);
            switch(opcion)
            {
            case 1:

                break;
            case 2:

                break;
            case 3:

                break;
            case 4:

                break;
            case 5:

                break;
            default:
                printf("Error, reingrese una opcion correcta (1-5)");
                break;
            }
            break;


        case 3:
            bajaSocio(socios, 10);

            break;
        case 4:
            mostrarSocios(socios, 10);

            break;
        case 5:
            mostrarLibros(libros, 10);

            break;
        case 6:
            mostrarAutores(autores, 10);

            break;
        case 7:
            printf(" ALMUERZOS");

            break;
        case 8:
            seguir = 'n';
            break;

        default:
            printf("Error, reingrese una opcion correcta (1-7)");
            break;
        }
        getch();
        system("cls");
    }


}
void mostrarAutores(eAutores autores[],int tam)
{
    for(int i=0; i<tam; i++)
    {
        printf("%5d %15s %15s\n", autores[i].codAutor, autores[i].apellido, autores[i].nombre);
    }
}

void mostrarLibros (eLibros libro[], int tam)
{

    printf("\n       Titulo    codLibro  codAutor\n\n");
    for(int i=0; i<tam; i++)
    {
        printf("%14s  %5d  %7d\n", libro[i].titulo, libro[i].codLibro, libro[i].codAutor);
    }
};

void mostrarSocios(eSocios socio[], int tam)
{
    for(int i=0; i<tam; i++)
    {
        if(socio[i].estado==1)
        {
            printf("%d %s %s %c %d %s\n", socio[i].codSocio, socio[i].apellido,socio[i].nombre,socio[i].sexo,socio[i].telefono,socio[i].email);
        }
    }
}

void bajaSocio(eSocios socio[],int tam)
{
    int legajo;
    mostrarSocios(socio, tam);
    printf("\nIngrese id de socio a dar de baja:");
    fflush(stdin);
    scanf("%d", &legajo);

    for(int i=0; i<tam; i++)
    {
        if(socio[i].codSocio == legajo)
        {
            socio[i].estado=0;
            printf("Baja con exito!!");
            break;
        }
    }
};

void altaSocio (eSocios socio[], int tam)
{

    eSocios nuevoSocio;
    int indice;
    indice = buscarLibreSocio(socio, tam);


    if(indice == -1)
    {
        printf("No hay lugar en el sistema");
    }
    else
    {

        getValidStringRango("Ingrese apellido :","\nIngrese solo letras!!!\n",nuevoSocio.apellido,31);
        getValidStringRango("Ingrese nombre :","\nIngrese solo letras!!!\n",nuevoSocio.nombre,31);
        nuevoSocio.sexo= getValidChar("Ingrese sexo (f/m)", "Error, ingrese sexo correcto (f/m)\n",'f','m');
        getStringNumeros("Ingrese numero telefonico", nuevoSocio.telefono, 16);


        socio[indice]=nuevoSocio;
        socio[indice].estado=1;
    }
}

void getValidStringRango(char requestMessage[],char errorMessage[], char input[], int tamanio)
{
    while(1)
    {
        if (!getStringLetrasRango(requestMessage,input, tamanio))
        {
            printf ("%s\n",errorMessage);
            fflush(stdin);
            continue;
        }

        break;
    }
}
int getStringLetrasRango(char mensaje[],char input[], int tamanio)
{
    char aux[256];
    getString(mensaje,aux);
    if(esSoloLetras(aux))
    {
        while(strlen(aux)>tamanio)
        {
            printf("\nError, supero la cantidad de caracteres permitidos\n\n");
            getString(mensaje,aux);
            continue;
        }
        corregirMayusculas(aux);
        strcpy(input,aux);
        return 1;
    }
    return 0;
}

void corregirMayusculas(char input[])
{
    int lenght;
    lenght = strlen(input);
    strlwr(input);
    input[0] = toupper(input[0]);
    for(int i=0; i<lenght; i++)
    {
        if(input[i] == ' ')
        {
            input[i+1] = toupper(input[i+1]);
        }
    }
}

int esSoloLetras(char str[])
{
    int i=0;
    while(str[i] != '\0')
    {
        if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z'))
            return 0;
        i++;
    }
    return 1;
}

void getString(char mensaje[],char input[])
{
    printf("%s",mensaje);
    fflush(stdin);
    scanf("%[^\n]s", input);
}


int buscarLibreSocio( eSocios socio[], int tam)
{
    int indice = -1;

    for(int i=0; i< tam; i++)
    {

        if( socio[i].estado == 0)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

char getValidChar(char requestMessage[], char errorMessage[], char comparacionA, char comparacionB)
{
    char auxiliar;
    printf("%s",requestMessage);
    fflush(stdin);
    scanf("%c",&auxiliar);
    while(auxiliar!=comparacionA && auxiliar!=comparacionB)
    {
        printf("\n%s",errorMessage);
        printf("\n%s",requestMessage);
        fflush(stdin);
        scanf("\n%c",&auxiliar);

    }
    return auxiliar;
}
int getValidInt(char requestMessage[],char errorMessage[])
{
    char auxStr[256];
    int auxInt;
    while(1)
    {
        if (!getStringNumeros(requestMessage,auxStr,16))
        {
            printf ("%s\n",errorMessage);
            continue;

        }
        auxInt = atoi(auxStr);
        return auxInt;
    }
}


int esNumerico(char str[])
{
    int i=0;
    while(str[i] != '\0')
    {
        if(str[i] < '0' || str[i] > '9')
            return 0;
        i++;
    }
    return 1;
}

int getStringNumeros(char mensaje[],char input[], int tam)
{
    char aux[256];
    getString(mensaje,aux);
    if(esNumerico(aux))
    {   while(strlen(aux)>tam){
        printf("\nError, supero la cantidad de caracteres permitidos\n\n");

    }
        strcpy(input,aux);
        return 1;
    }

    return 0;
}

