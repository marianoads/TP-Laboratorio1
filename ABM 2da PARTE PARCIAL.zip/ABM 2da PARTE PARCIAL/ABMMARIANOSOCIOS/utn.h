#ifndef SOCIOS_H_INCLUDED
#define SOCIOS_H_INCLUDED

/**
* \brief Solicita un n�mero entero al usuario y lo valida
* \param input Se carga el numero ingresado
* \param message Es el mensaje a ser mostrado
* \param eMessage Es el mensaje a ser mostrado en caso de error
* \param lowLimit Limite inferior a validar
* \param hiLimit Limite superior a validar
* \return Si obtuvo el numero [0] si no [-1]
*
*/
int getInt(int* input,char message[],char eMessage[], int lowLimit, int hiLimit);

/**
* \brief Solicita un n�mero real al usuario y lo valida
* \param input Se carga el numero ingresado
* \param message Es el mensaje a ser mostrado
* \param eMessage Es el mensaje a ser mostrado en caso de error
* \param lowLimit Limite inferior a validar
* \param hiLimit Limite superior a validar
* \return Si obtuvo el numero [0] si no [-1]
*
*/
int getFloat(float* input,char message[],char eMessage[], float lowLimit, float hiLimit);

/**
* \brief Solicita un caracter al usuario y lo valida
* \param input Se carga el caracter ingresado
* \param message Es el mensaje a ser mostrado
* \param eMessage Es el mensaje a ser mostrado en caso de error
* \param lowLimit Limite inferior a validar
* \param hiLimit Limite superior a validar
* \return Si obtuvo el caracter [0] si no [-1]
*
*/
int getChar(char* input,char message[],char eMessage[], char lowLimit, char hiLimit);

/**
* \brief Solicita una cadena de caracteres al usuario y la valida
* \param input Se carga la cadena ingresada
* \param message Es el mensaje a ser mostrado
* \param eMessage Es el mensaje a ser mostrado en caso de error
* \param lowLimit Longitud m�nima de la cadena
* \param hiLimit Longitud m�xima de la cadena
* \return Si obtuvo la cadena [0] si no [-1]
*
*/
int getStringNumeros(char* input,char message[],char eMessage[], int lowLimit, int hiLimit);

/**
* \brief Solicita una caracter para el sexo al usuario y valida que sea f o m.
* \param input Carga el char ingresado.
* \param message Es el mensaje a ser mostrado.
* \param eMessage Es el mensaje a ser mostrado en caso de error.
* \return Si obtuvo la cadena [0] si no [-1]
*
*/
int getCharGenre(char* input,char message[],char eMessage[]);

/**
* \brief Permite el ingreso de una fecha. Valida si el a�o es bisiesto y el n�mero de d�as de cada mes.
* \param inputA Carga el a�o ingresado.
* \param inputA Carga el n�mero del mes ingresado.
* \param inputD Carga el n�mero del d�a ingresado.
* \param message Es el mensaje a ser mostrado concatenado con "Ingrese la fecha de ".
* \param anioLowLimit Limite inferior a validar para los a�os.
* \param anioHiLimit Limite superior a validar para los a�os.
* \return Si obtuvo la cadena [0] si no [-1]
*
*/
int getDate(int* inputA, int* inputM, int* inputD, char message[], int AnioLowLimit, int AnioHiLimit);

/** \brief Permite el ingreso de un celular. Valida cantidad de caracteres que esten entre el rango que desee el usuario
 *
 * \param AnioLowLimit limite inferior de cantidad de caracteres
 * \param   AnioHiLimit limite superior de cantidad de caracteres
 * \return Si cumple con la condicion devuelve 1, en el caso contrario devuelve 0
 *
 */
int getCelular(int* input,char message[],char eMessage[], int lowLimit, int hiLimit);
/**
 * \brief Solicita un numero entero al usuario y lo valida
 * \param requestMessage Es el mensaje a ser mostrado para solicitar el dato
 * \param requestMessage Es el mensaje a ser mostrado en caso de error
 * \return El n�mero ingresado por el usuario
 *
 */
int getValidInt(char requestMessage[],char errorMessage[]);
/**
 * \brief Solicita un texto al usuario y lo devuelve
 * \param mensaje Es el mensaje a ser mostrado
 * \param input Array donde se cargar� el texto ingresado
 * \return void
 */
int getString(char mensaje[],char input[]);

/**
 * \brief Verifica si el valor recibido es num�rico
 * \param str Array con la cadena a ser analizada
 * \return 1 si es n�merico y 0 si no lo es
 *
 */
int esNumerico(char str[]);
/** \brief Obtiene y valida una cadena de caracteres
 *
 * \param requestMessage[] Mensaje a mostrar
 * \param errorMessage[] Mensaje de error
 * \param input[] variable de retorno por referencia
 * \param tamanio cantidd de caracteres permitidos
 * \return void
 *
 */
void getValidStringRango(char requestMessage[],char errorMessage[], char input[], int tamanio);
/** \brief Obtiene un string
 *
 * \param mensaje[] Mensaje a mostrar
 * \param input[] variable de retorno por referencia
 * \param tamanio cantidd de caracteres permitidos
 * \return int (1) si es solo letras - (0) si no lo es
 *
 */
int getStringLetrasRango(char mensaje[],char input[], int tamanio);
/**
 * \brief Verifica si el valor recibido contiene solo letras
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo ' ' y letras y 0 si no lo es
 *
 */
int esSoloLetras(char str[]);
/** \brief Cambia las primeras letras a mayusculas
 *
 * \param input[] Cadena a modificar
 * \return void
 *
 */
void corregirMayusculas(char input[]);
/** \brief retorna un caracter validado con 2 comparaciones
 *
 * \param requestMessage[] char mensaje solicitando ingreso de datos
 * \param errorMessage[] char mensaje de error
 * \param comparacionA char primera comparacion
 * \param comparacionB char primera comparacion
 * \return char caracter valido
 *
 */
char getValidChar(char requestMessage[], char errorMessage[], char comparacionA, char comparacionB);



#endif
