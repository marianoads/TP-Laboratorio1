#include "socios.h"
#include "utn.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <stdlib.h>


int menu()
{
    int opcion;

    system("cls");
    printf("  --- ABM Socios ---\n\n");
    printf("1- Alta de Socio\n");
    printf("2- Modificar Socio\n");
    printf("3- Baja de Socio\n");
    printf("4- Listar Socios\n");
    printf("5- Listar Libros\n");
    printf("6- Listar Autores\n");
    printf("7- Alta Prestamos\n");
    printf("8- Informar y listar\n");
    printf("9- Salir\n");

    getInt(&opcion,"Ingrese una opcion: "," Opcion invalida !!!", 1, 9);

    return opcion;
}

int abmListar(eSocio socio[],int TAM_SOC, ePrestamo prestamo[],int TAM_PRES, eLibro libro[], int TAM_LIB, eAutor autor[], int TAM_AUT){
    int opcion;
    char seguir = 's';

    system("cls");
    printf("  --- ABM Socios ---\n\n");
    printf("1- Informar total general y promedio diario\n");
    printf("2- Informar cantidad de dias\n");
    printf("3- Listar todos los socios que solitaron un libro\n");
    printf("4- Listar todos los libros que fueron solicitados por un socio\n");
    printf("5- Listar el/los libros menos solicitados en un prestamo\n");
    printf("6- Listar el/los socios que realizaron mas solicitudes a prestamo\n");
    printf("7- Listar todos los libros solicitados a prestamo en una fecha determinada\n");
    printf("8- Listar todos los socios que realizaron al menos una solicitud de prestamo\n");
    printf("9- Listar todos los libros ordenados por titulo (descendente)\n");
    printf("10- Listar todos los socios ordenados por apellido (ascendente)\n");
    printf("11- Salir\n");

    getInt(&opcion,"Ingrese una opcion: "," Opcion invalida !!!", 1, 11);

    switch(opcion)
        {

        case 1:

            mostrarTotalPrestamo(prestamo, TAM_PRES);
            system("pause");
            break;

        case 2:


            break;

        case 3:

           listarSocioXLibroDeterminado(socio, TAM_SOC,prestamo,TAM_LIB, libro, TAM_LIB);
           system("pause");
        case 4:


            break;

        case 5:

            break;

        case 6:

            break;

        case 7:


            break;
        case 8:

            break;
        case 9:
            listarLibrosOrdenadosPorTitulo(libro, TAM_LIB);
        system("pause");

        case 10:
          mostrarSociosOrdenadosAscende(socio, TAM_SOC);
          system("pause");
        case 11:

          break;

        default:
            printf("\n Opcion invalida (1-11)\n\n");
            system("pause");

        }
}


void mostrarSocio(eSocio socio)
{

    printf("%3d %10s %10s %6c %15d %10s %02d/%02d/%d\n", socio.idSocio, socio.apellido, socio.nombre, socio.sexo, socio.telefono, socio.email, socio.fecha.dia, socio.fecha.mes, socio.fecha.anio);

}

void mostrarLibro(eLibro libro)
{

    printf("%d\t%s\t%d\n", libro.idLibro, libro.titulo, libro.idAutor);

}

void mostrarAutor(eAutor autor)
{

    printf("%d\t%s\t%s\n", autor.idAutor, autor.apellidoA, autor.nombreA);

}

void mostrarSociosOrdenados(eSocio vec[], int tam)
{
    int contador = 0;
    eSocio auxSocio;

    for(int i=0; i<tam-1; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if(strcmp(vec[i].apellido, vec[j].apellido)>0)
            {
                auxSocio = vec[i];
                vec[i] = vec[j];
                vec[j] = auxSocio;
            }
        }
    }

    printf("\nCod   Apellido    Nombre     Sexo           Tel     eMail     Fecha de Alta\n");

    for(int i=0; i < tam; i++)
    {
        if(vec[i].ocupado == 1)
        {
            mostrarSocio(vec[i]);
            contador++;
        }
    }

    if( contador == 0)
    {
        printf("\n ii No existe ningun socio !!\n");
    }
}

void mostrarLibrosOrdenados(eLibro vec[], int tam)
{
    int contador = 0;
    eLibro auxLibro;

    for(int i=0; i<tam-1; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if(strcmp(vec[i].titulo, vec[j].titulo)<0)
            {
                auxLibro = vec[i];
                vec[i] = vec[j];
                vec[j] = auxLibro;
            }
        }
    }

    printf("\nCodigo\tTitulo\tID Autor\n");

    for(int i=0; i < tam; i++)
    {
        if(vec[i].ocupado == 1)
        {
            mostrarLibro(vec[i]);
            contador++;
        }
    }

    if( contador == 0)
    {
        printf("\n(!) No hay libros que mostrar (!)\n");
    }
}

void mostrarAutoresOrdenados(eAutor vec[], int tam)
{
    int contador = 0;
    eAutor auxAutor;

    for(int i=0; i<tam-1; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if(strcmp(vec[i].apellidoA, vec[j].apellidoA)>0)
            {
                auxAutor = vec[i];
                vec[i] = vec[j];
                vec[j] = auxAutor;
            }
        }
    }

    printf("\nID\tApellido\tNombre\n");

    for(int i=0; i < tam; i++)
    {
        if(vec[i].ocupado == 1)
        {
            mostrarAutor(vec[i]);
            contador++;
        }
    }

    if( contador == 0)
    {
        printf("\n ii No existen autores !!\n");
    }
}


int buscarLibre(eSocio vec[], int tam)
{

    int indice = -1;

    for(int i=0; i < tam; i++)
    {
        if(vec[i].ocupado == 0)
        {
            indice = i;
            break;
        }
    }

    return indice;
}

int buscarPrestamoLibre(ePrestamo vec[], int tam)
{

    int indice = -1;

    for(int i=0; i < tam; i++)
    {
        if(vec[i].ocupado == 0)
        {
            indice = i;
            break;
        }
    }

    return indice;
}

void inicializarSocios(eSocio vec[], int tam)
{
    for(int i=0; i < tam; i++)
    {
        vec[i].ocupado = 0;
    }
}

void inicializarPrestamos(ePrestamo vec[], int tam)
{
    for(int i=0; i < tam; i++)
    {
        vec[i].ocupado = 0;
    }
}

int altaSocio(eSocio socio[], int tam, int idMain)
{

    int indice;
    int altaOk = 0;

    indice = buscarLibre(socio, tam);

    if( indice == -1)
    {
        printf("\n(!) No hay lugar en el sistema (!)\n\n");
    }
    else
    {
        socio[indice].idSocio = idMain++;

        getStringNumeros(socio[indice].nombre,"Ingrese el nombre: ","(!) Largo del nombre invalido (!)", 2, 31);

        getStringNumeros(socio[indice].apellido,"Ingrese el apellido: ","(!) Largo del apellido invalido (!)", 2, 31);

        getCharGenre(&socio[indice].sexo,"Ingrese el sexo: ","(!) Debe ingresar F o M (!)");

        getCelular(socio[indice].telefono,"Ingrese el telefono","(!) Telefono invalido (!)", 8, 16);

        getStringNumeros(socio[indice].email,"Ingrese el email: ","(!) Largo del email invalido (!)", 5, 31);

        getDate(&socio[indice].fecha.anio, &socio[indice].fecha.mes, &socio[indice].fecha.dia, "alta:", 2010, 2020);

        socio[indice].ocupado = 1;

        printf("\n-- Socio dado de alta exitosamente --\n\n");

        altaOk=1;
    }

    return altaOk;
}

int buscarSocio(eSocio vec[], int tam, int id)
{

    int indice = -1;

    for(int i=0; i < tam; i++)
    {
        if(vec[i].ocupado == 1 && vec[i].idSocio == id)
        {
            indice = i;
            break;
        }
    }

    return indice;
}

void bajaSocio(eSocio vec[], int tam)
{
    int id;
    int indice;
    char baja;

    getInt(&id,"\nIngrese el id del socio a dar de baja: ","(!) No es un id valido (!)\n", 1, 5000);

    indice = buscarSocio(vec, tam, id);

    if( indice == -1)
    {
        printf("\n(!) No existe un socio con ese id (!)\n");
    }
    else
    {
        mostrarSocio(vec[indice]);
        printf("\nDesea dar de baja al empleado? s/n: ");
        baja = getche();
        if(tolower(baja)=='s')
        {
            vec[indice].ocupado=0;
            printf("\n-- Empleado dado de baja exitosamente --\n");
        }
    }
}

int altaPrestamos(ePrestamo prestamo[], int tamPrest, eSocio socio[], int tamSocio, eLibro libro[], int tamLibro, int idPMain, int idSocioMain)
{
    int indice;
    int altaOk = 0;

    indice = buscarPrestamoLibre(prestamo, tamPrest);

    if( indice == -1)
    {
        printf("\n(!) No hay lugar en el sistema (!)\n\n");
    }
    else
    {
        prestamo[indice].idP = idPMain++;

        mostrarSociosOrdenados(socio, tamSocio);

        getInt(&prestamo[indice].idSocio,"Ingrese el ID del socio: ","ii ID no existe !!", 1, idSocioMain);

        mostrarLibrosOrdenados(libro, tamLibro);

        getInt(&prestamo[indice].idLibro,"Ingrese el ID del libro: ","ii ID no existe !!", 1, 2000);

        getDate(&prestamo[indice].fechaPrestamo.anio, &prestamo[indice].fechaPrestamo.mes, &prestamo[indice].fechaPrestamo.dia, "prestamo:", 2005, 2020);

        prestamo[indice].ocupado = 1;

        prestamo[indice].contPrest++;

        printf("\n-- Prestamo dado de alta exitosamente --\n\n");

        altaOk=1;
    }

    return altaOk;
}

void modificarSocio (eSocio socio[],int TAM_SOC,int id)
{

    int indice;
    int legajo;
    int opcion;
    char auxSexo;


    char confirmacion;
    printf("Socios :\n\n");
    for(int i=0; i<TAM_SOC; i++)
    {
        if(socio[i].ocupado==1)
        {
            printf(" Id: %d    Apellido: %s      Nombre: %s\n", socio[i].idSocio, socio[i].apellido, socio[i].nombre);
        }
    }

    printf("\n\nIngrese codigo de socio :");
    fflush(stdin);
    scanf("%d", &legajo);

    indice   = buscarSocio(socio, TAM_SOC, legajo);

    if (indice == -1)
    {
        printf("\nNo existe ningun socio con el numero :%d\n", legajo);

    }
    else
    {   system("cls");
        printf("Menu modificacion para socio: %s %s\n\n", socio[indice].apellido, socio[indice].nombre);
        printf("**Menu de opciones**\n\n1- Apellido\n2- Nombre\n3- Sexo\n4- Telefono\n5- eMail\n6- Salir\n\n");
        printf("Ingrese opcion :");
        fflush(stdin);
        scanf("%d", &opcion);
        switch(opcion)
        {
        case 1:
            getStringNumeros(socio[indice].apellido,"Ingrese el apellido: ","(!) Largo del apellido invalido (!)", 2, 31);

            printf("Se modifico con exito\n");
            break;

        case 2:
            getStringNumeros(socio[indice].nombre,"Ingrese el nombre: ","(!) Largo del nombre invalido (!)", 2, 31);

            printf("Se modifico con exito\n");
            break;
        case 3:
            auxSexo = getValidChar("Ingrese nuevo sexo: ", "Error, solo letras.\n", 'm', 'f');
            printf("\nSe modificara \"%c\" por \"%c\"\n", auxSexo, socio[indice].sexo);
            confirmacion = getValidChar("\nIngrese confirmacion (s/n): ", "Error\n", 's', 'n');
            if(confirmacion == 's')
            {
                socio[indice].sexo = auxSexo;
                printf("Se modifico con exito\n");
            }
            else
            {
                printf("Se cancelo modificacion\n");
            }

            break;
        case 4:
            getCelular(socio[indice].telefono,"Ingrese el telefono","(!) Telefono invalido (!)", 8, 16);

            break;
        case 5:
            getStringNumeros(socio[indice].email,"Ingrese el email: ","(!) Largo del email invalido (!)", 5, 31);
            break;
        case 6:
            break;

        default:
            printf("Ingrese una opcion correcta (1-6)\n\n!!");

        }

    }

}



void listarLibrosOrdenadosPorTitulo (eLibro vec[], int tam) {
 int contador = 0;
    eLibro auxLibro;

    for(int i=0; i<tam-1; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if(strcmp(vec[i].titulo, vec[j].titulo)<0)
            {
                auxLibro = vec[i];
                vec[i] = vec[j];
                vec[j] = auxLibro;
            }
        }
    }

    printf("\nCodigo\tTitulo\tID Autor\n");

    for(int i=0; i < tam; i++)
    {
        if(vec[i].ocupado == 1)
        {
            mostrarLibro(vec[i]);
            contador++;
        }
    }

    if( contador == 0)
    {
        printf("\n(!) No hay libros que mostrar (!)\n");
    }
};

void mostrarSociosOrdenadosAscende(eSocio socio[], int TAM_SOC){
  int contador = 0;
    eSocio auxSocio;

    for(int i=0; i<TAM_SOC-1; i++)
    {
        for(int j=i+1; j<TAM_SOC; j++)
        {
            if(strcmp(socio[i].apellido, socio[j].apellido)>0)
            {
                auxSocio = socio[i];
                socio[i] = socio[j];
                socio[j] = auxSocio;
            }
        }
    }

    printf("\nCod   Apellido    Nombre     Sexo           Tel     eMail     Fecha de Alta\n");

    for(int i=0; i < TAM_SOC; i++)
    {
        if(socio[i].ocupado == 1)
        {
            mostrarSocio(socio[i]);
            contador++;
        }
    }

    if( contador == 0)
    {
        printf("\n ii No existe ningun socio !!\n");
    }
}

void listarSocioXLibroDeterminado (eSocio socio[], int TAM_SOC, ePrestamo prestamo[],int TAM_PRES,eLibro libro[], int TAM_LIB){
    int i,j;
    int codLibro;
    mostrarLibrosOrdenados(libro, TAM_LIB);
    printf("Ingrese codigo de libro :");
    scanf("%d", &codLibro);





};


void mostrarTotalPrestamo (ePrestamo prestamo[],int TAM_PRES){
    int contadorPrest =0;
    for(int i=0;i<TAM_PRES;i++){
        if(prestamo[i].ocupado==1){
            contadorPrest++;
        }
    }
        if(contadorPrest!= 0){
            printf("Cantidad total de prestamos : %d", contadorPrest);
        }
        else{printf("No se encontro ningun prestamo dado de alta!!\n");
        }
}

