#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "socios.h"
#include"utn.h"


int getInt(int* input,char message[],char eMessage[], int lowLimit, int hiLimit)
{
    int valor;
    int returnScanf;
    int error = -1;

    printf("%s ", message);
    returnScanf = scanf("%d", &valor);

    while(returnScanf == 0 || valor < lowLimit || valor > hiLimit)
    {

        printf("\n%s\n", eMessage);
        printf("\n%s ", message);
        fflush(stdin);
        returnScanf = scanf("%d", &valor);
    }

    *input = valor;
    error = 0;

    return error;
}

int getFloat(float* input,char message[],char eMessage[], float lowLimit, float hiLimit)
{
    float valor;
    int returnScanf;
    int error = -1;

    printf("%s ", message);
    returnScanf = scanf("%f", &valor);

    while(returnScanf == 0 || valor < lowLimit || valor > hiLimit)
    {

        printf("\n%s\n", eMessage);
        printf("\n%s ", message);
        fflush(stdin);
        returnScanf = scanf("%f", &valor);
    }

    *input = valor;
    error = 0;

    return error;
}

int getChar(char* input,char message[],char eMessage[], char lowLimit, char hiLimit)
{
    char valor;
    int error = -1;

    printf("%s ", message);
    fflush(stdin);
    scanf("%c", &valor);

    while(valor < lowLimit || valor > hiLimit)
    {
        printf("\n%s\n", eMessage);
        printf("\n%s ", message);
        fflush(stdin);
        scanf("%c", &valor);
    }

    *input = valor;
    error = 0;

    return error;


}

int getStringNumeros(char* input,char message[],char eMessage[], int lowLimit, int hiLimit)
{
    char valor[50];
    int error = -1;

    printf("%s ", message);
    fflush(stdin);
    gets(valor);

    while(strlen(valor) < lowLimit || strlen(valor) > hiLimit)
    {
        printf("\n%s\n", eMessage);
        printf("\n%s ", message);
        fflush(stdin);
        gets(valor);
    }

    strcpy(input,valor);

    error = 0;

    return error;
}

int getCharGenre(char* input,char message[],char eMessage[])
{
    char valor;
    int error = -1;

    printf("%s ", message);
    fflush(stdin);
    scanf("%c", &valor);
    valor=toupper(valor);

    while(valor !='F' && valor !='M')
    {
        printf("\n%s\n", eMessage);
        printf("\n%s ", message);
        fflush(stdin);
        scanf("%c", &valor);
        valor=toupper(valor);
    }

    *input = valor;
    error = 0;

    return error;
}

int getDate(int* inputA, int* inputM, int* inputD, char message[], int anioLowLimit, int anioHiLimit)
{
    int dia;
    int mes;
    int anio;
    int leap=0;//Bandera para los a�os bisiestos.
    int error = -1;
    char mensajeAnio[50]="Ingrese el anio de ";
    char mensajeMes[50]="Ingrese el mes de ";
    char mensajeDia[50]="Ingrese el dia de ";

    strcat(mensajeAnio, message);
    strcat(mensajeMes, message);
    strcat(mensajeDia, message);

    getInt(&anio,mensajeAnio,"***Error, el anio ingresado no es valido ***\n", anioLowLimit, anioHiLimit);

    if(anio % 4 == 0 && (anio % 100 != 0 || anio % 400 == 0))
    {
        leap=1;
    }

    *inputA = anio;

    getInt(&mes,mensajeMes,"***Error, el mes ingresado no es valido ***\n", 1, 12);

    *inputM = mes;

    if(leap==0 && mes == 2)
    {

        getInt(&dia,mensajeDia,"*** Error, no es un dia valido mes ingresado ***\n", 1, 28);

    }
    else if(leap==1 && mes == 2)
    {

        getInt(&dia,mensajeDia,"*** Error, no es un dia valido mes ingresado ***\n", 1, 29);

    }
    else if(mes == 4 || mes == 6 || mes == 9 || mes == 11)
    {


        getInt(&dia,mensajeDia,"*** No es un dia valido para el mes ingresado ***\n", 1, 30);

    }
    else
    {
        getInt(&dia,mensajeDia,"(!) No es un dia valido (!)\n", 1, 31);
    }

    *inputD = dia;

    error = 0;

    return error;
}

int getCelular(int* input,char message[],char eMessage[], int lowLimit, int hiLimit)
{
    int valor[50];
    int error = -1;

    printf("%s ", message);
    fflush(stdin);
    gets(valor);

    while(strlen(valor) < lowLimit || strlen(valor) > hiLimit)
    {
        printf("\n%s\n", eMessage);
        printf("\n%s ", message);
        fflush(stdin);
        gets(valor);
    }

    strcpy(input,valor);

    error = 0;

    return error;
}

int getValidInt(char requestMessage[],char errorMessage[])
{
    char auxStr[256];
    int auxInt;
    while(1)
    {
        if (!getString(requestMessage,auxStr))
        {
            printf ("%s\n",errorMessage);
            continue;

        }
        auxInt = atoi(auxStr);
        return auxInt;
    }
}

int getString(char mensaje[],char input[])
{
    char aux[256];
    getString(mensaje,aux);
    if(esNumerico(aux))
    {
        strcpy(input,aux);
        return 1;
    }
    return 0;
}

int esNumerico(char str[])
{
    int i=0;
    while(str[i] != '\0')
    {
        if(str[i] < '0' || str[i] > '9')
            return 0;
        i++;
    }
    return 1;
}

void getValidStringRango(char requestMessage[],char errorMessage[], char input[], int tamanio)
{
    while(1)
    {
        if (!getStringLetrasRango(requestMessage,input, tamanio))
        {
            printf ("%s\n",errorMessage);
            fflush(stdin);
            continue;
        }

        break;
    }
}

int getStringLetrasRango(char mensaje[],char input[], int tamanio)
{
    char aux[256];
    getString(mensaje,aux);
    if(esSoloLetras(aux))
    {
        while(strlen(aux)>tamanio)
        {
            printf("\nError, supero la cantidad de caracteres permitidos\n\n");
            getString(mensaje,aux);
            continue;
        }
        corregirMayusculas(aux);
        strcpy(input,aux);
        return 1;
    }
    return 0;
}

void corregirMayusculas(char input[])
{
    int lenght;
    lenght = strlen(input);
    strlwr(input);
    input[0] = toupper(input[0]);
    for(int i=0; i<lenght; i++)
    {
        if(input[i] == ' ')
        {
            input[i+1] = toupper(input[i+1]);
        }
    }
}


int esSoloLetras(char str[])
{
    int i=0;
    while(str[i] != '\0')
    {
        if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z'))
            return 0;
        i++;
    }
    return 1;
}

char getValidChar(char requestMessage[], char errorMessage[], char comparacionA, char comparacionB)
{
    char auxiliar;
    printf("%s",requestMessage);
    fflush(stdin);
    scanf("%c",&auxiliar);
    while(auxiliar!=comparacionA && auxiliar!=comparacionB){
        printf("\n%s",errorMessage);
        printf("\n%s",requestMessage);
        fflush(stdin);
        scanf("\n%c",&auxiliar);

    }
    return auxiliar;
}

