#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>

#include "utn.h"
#include "socios.h"

#define TAM_AUT 5
#define TAM_LIB 7
#define TAM_SOC 10
#define TAM_PRES 5





int main()
{

    eAutor listaAutores[TAM_AUT]= {{101,"Enrique","Matas",1},{102,"Carlos ","Sisi",1},{103,"German","Melville",1},{104,"Stephe","King",1},{105,"Dan","Brown",1}};

    eLibro listaLibros[TAM_LIB]= {{1001,"Luces de bohemia",101,1},{1002,"Crimen y castigo",103,1},{1003,"100 a�os de Soledad",104,1},{1004,"La casa de los esp�ritus",105,1},{1005,"Preludio a la fundaci�n",103,1},{1006,"Las almas muertas",105,1},{1007,"La comedia humana",102,1}};


    eSocio listaSocios[TAM_SOC];

    ePrestamo listaPrestamos[TAM_PRES];

    char seguir = 's';
    char confirma;
    int flag;
    int idAutoIn=1;
    int idAutoInPrestamo=1;

    inicializarSocios(listaSocios, TAM_SOC);
    inicializarPrestamos(listaPrestamos, TAM_PRES);

    do
    {
        switch(menu())
        {

        case 1:


            flag = altaSocio(listaSocios, TAM_SOC, idAutoIn);

            if(flag){

                idAutoIn ++;
            }

            flag=0;

            system("pause");
            break;

        case 2:

            modificarSocio(listaSocios, TAM_SOC, idAutoIn);
            system("pause");
            break;

        case 3:

            bajaSocio(listaSocios, TAM_SOC);
            system("pause");
            break;

        case 4:

            mostrarSociosOrdenados(listaSocios, TAM_SOC);
            system("pause");
            break;

        case 5:
            mostrarLibrosOrdenados(listaLibros, TAM_LIB);
            system("pause");
            break;

        case 6:

            mostrarAutoresOrdenados(listaAutores, TAM_AUT);
            system("pause");
            break;

        case 7:

              flag = altaPrestamos(listaPrestamos, TAM_PRES, listaSocios, TAM_SOC, listaLibros, TAM_LIB, idAutoInPrestamo, idAutoIn);

            if(flag){

                idAutoIn ++;
            }

            flag=0;

            system("pause");
            break;
        case 8:
            abmListar(listaSocios,TAM_SOC,listaPrestamos,TAM_PRES,listaLibros,TAM_LIB,listaAutores,TAM_AUT);
            break;


        case 9:
            printf("\nDesea salir del programa? s/n: ");
            fflush(stdin);
            confirma = getche();

            if( tolower(confirma) == 's')
            {
                    seguir = 'n';
            }
            break;

        default:
            printf("\n Opcion invalida\n\n");
            system("pause");
        }
    }
    while(seguir == 's');

    return 0;

}
