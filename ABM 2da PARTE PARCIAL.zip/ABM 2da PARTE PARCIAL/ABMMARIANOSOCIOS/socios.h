typedef struct
{
    int dia;
    int mes;
    int anio;
} eFecha;

typedef struct
{
    int idAutor;
    char apellidoA[31];
    char nombreA[31];
    int ocupado;
} eAutor;

typedef struct
{
    int idLibro;
    char titulo[51];
    int idAutor;
    int ocupado;
} eLibro;

typedef struct
{
    int idSocio;
    char nombre[31];
    char apellido[31];
    char sexo;
    int telefono[16];
    char email[31];
    eFecha fecha;
    int ocupado;
} eSocio;

typedef struct
{
    int idP;
    int idLibro;
    int idSocio;
    eSocio codSoc;
    eLibro codLib;
    eFecha fechaPrestamo;
    int ocupado;
    int contPrest;
} ePrestamo;

int menu();
int abmListar();
void mostrarSocio(eSocio socio);
void mostrarSociosOrdenados(eSocio vec[], int tam);
int altaSocio(eSocio vec[], int tam, int idMain);
void modificarSocio (eSocio socio[],int TAM_SOC,int id);
void inicializarSocios(eSocio vec[], int tam);
int buscarSocio(eSocio vec[], int tam, int id);
void bajaSocio(eSocio vec[], int tam);
void mostrarLibro(eLibro libro);
void mostrarLibrosOrdenados(eLibro vec[], int tam);
void mostrarAutor(eAutor autor);
void mostrarAutoresOrdenados(eAutor vec[], int tam);
int altaPrestamos(ePrestamo vecP[], int tamP, eSocio vecS[], int tamS, eLibro vecL[], int tamL, int idPMain, int idSMain);
void inicializarPrestamos(ePrestamo vec[], int tam);
void listarSocioXLibroDeterminado (eSocio socio[], int TAM_SOC, ePrestamo prestamo[],int TAM_PRES,eLibro libro[], int TAM_LIB);
void listarLibrosOrdenadosPorTitulo (eLibro vec[], int tam);
void mostrarSociosOrdenadosAscende(eSocio socio[], int TAM_SOC);
void libroEnFechaDeterminada(ePrestamo listPrest[],int lenPres,eLibro listLibro[],int lenLibro,eAutor listAu[],int lenAut);
void mostrarTotalPrestamo (ePrestamo prestamo[],int TAM_PRES);
